# how to run this project

# login to website
https://speakeasy.ifi.uzh.ch/

request chat with `fierce-blade`

# Local steps:
- change your shell to your environment (conda, venv, etc)
- `poetry install` to install dependencies and create environment
- `uvicorn app.main:app --reload` to run the project

# To download dataset
- run `python ./utils/download_dataset.py` to download the dataset

# For "production" - preloads everything
- `uvicorn app.main:app`


# Current extractor approach
- We have an NLP query
    - We remove the question mark
    1) Movie Extractor 
        - 1. Extract with NLTK with levhenstein distance for most similar words (with hypens variations if they exist)
        - 1a If no match was found, we extract with fuzzy matcher (maximally one movie will be returned on this point right now)
        - 2. it is theoretically possible to run NER on movies and then fuzzy match them against the extracted movie names but too much work
            - it would work good when we want to extract all movies from a text but nltk with better algo could solve thiss as well
    2) Relationship extractor
        - 1. Manual extraction (like publication date which is weird)
        - 2. Extract with NLTK with levhenstein distance for most similar words (works perfectly for directors and similar)
            - 2a. Extract with fuzzy matcher (maximally one movie will be returned on this point right now - but not that good for relations)
        - 3. Run embedding search
            - Take all relations and embedd them into space
            - take the query without movie remove all stopwords and embedd it, hopefully we get some relationships


# 2nd evaulation - Example queries
- `Who directed the movie "The Matrix"?`
- `What is the genre of the movie "The Matrix"?`
- `What is the publication date of the movie "The Matrix"?`
- `What is the duration of the movie "The Matrix"?`