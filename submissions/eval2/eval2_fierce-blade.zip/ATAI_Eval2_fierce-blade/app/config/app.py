import os
import sys
from app.config.enums import Environment

from pydantic_settings import BaseSettings, SettingsConfigDict

from app.config.enums import Milestone


class Config(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8')

    bot_username: str
    bot_password: str
    default_host_url: str = "https://speakeasy.ifi.uzh.ch"
    listen_freq: int = 2
    utils_path: str = os.path.dirname(__file__).rpartition("app")[0] + "utils"
    milestone: Milestone = Milestone.TWO
    environment: Environment = Environment.DEV if "dev" in sys.argv or "--reload" in sys.argv else Environment.PROD


# Instantiate the settings
settings = Config()
