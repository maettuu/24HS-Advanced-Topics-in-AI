import os
import json
import spacy
from fuzzywuzzy import process
from app.config.app import settings
import re

class Extractor:
    def __init__(self):
        with open(os.sep.join((settings.utils_path, "useful_dataset/graph/unique_movies.json"))) as f:
            self.entities = json.load(f)

        with open(os.sep.join((settings.utils_path, "useful_dataset", "graph", "unique_relationships.json"))) as f:
            self.relations = json.load(f)

class SpacyExtractor(Extractor):
    def __init__(self):
        # Load the spaCy model from the saved path
        path = os.sep.join((settings.utils_path, "test_scripts", "spacy_rule_based_recognition", "movie_relation_ner_model"))
        self.nlp = spacy.load(path)
        self.score = 90 #score for similarity - set higher for more strict matching
        self.hyphen_variants = ['-', '–', '—']
        super().__init__() #get relations and entities from the parent class

    def preprocess_text(self, text: str) -> str:
        # Standardize colons to ensure consistency
        text = re.sub(r":", ":", text)  # This line seems redundant but kept for consistency
        return text

    def generate_hyphen_variants(self, text: str) -> list:
        """
        Generate all mutated versions of the input text by replacing hyphens with different variants.
        To avoid combinatorial explosion, replace all hyphens in one step with each variant.
        """
        # Find all hyphen-like characters in the text
        hyphen_pattern = r'[-–—]'
        if not re.search(hyphen_pattern, text):
            return [text]  # No hyphens to replace

        # Generate mutated texts by replacing all hyphens with each variant
        mutated_texts = []
        for variant in self.hyphen_variants:
            mutated = re.sub(hyphen_pattern, variant, text)
            mutated_texts.append(mutated)
        
        return mutated_texts

    # Be aware that fuzzy match searches only for one entity
    def fuzzy_match_entity(self, input_text, labels):
        # Use fuzzy matching to find the closest match to the input text from a list of labels
        results = process.extract(input_text, labels, limit=5)  # Get the top 5 matches
        results = sorted(results, key=lambda x: (-x[1], -len(x[0])))  # Sort by score, then by length

        # Return the highest-scoring and longest match above the score threshold
        for match, score in results:
            if score > self.score:
                return match
        return None

    def get_entities_with_fuzzy_matching(self, text: str, type: str = "all") -> dict:
        text = self.preprocess_text(text)  # Preprocess the text for consistent matching

        # Generate all hyphen variants
        mutated_texts = self.generate_hyphen_variants(text)

        all_movies = []
        all_relations = []

        for mutated_text in mutated_texts:
            doc = self.nlp(mutated_text)  # Process the mutated text using the loaded spaCy model
            # Exact matching via spaCy
            for ent in doc.ents:
                if ent.label_ == "movie":
                    all_movies.append({'text': ent.text, 'start': ent.start_char, 'end': ent.end_char})
                elif ent.label_ == "relation":
                    all_relations.append({'text': ent.text, 'start': ent.start_char, 'end': ent.end_char})

        # Remove duplicates by converting list of dicts to set of tuples and back
        all_movies = [dict(t) for t in {tuple(d.items()) for d in all_movies}]
        all_relations = [dict(t) for t in {tuple(d.items()) for d in all_relations}]

        # Remove shorter matches if they overlap with longer ones
        movies = self.filter_overlapping_matches(all_movies)
        relations = self.filter_overlapping_matches(all_relations)

        print("Exact matches found:")
        print("Movies:", [movie['text'] for movie in movies])
        print("Relations:", [relation['text'] for relation in relations])

        # Fallback to fuzzy matching if no exact matches are found or to extend partial matches
        # Currently run only if no matches are found, extending not possible (hypen error seems to be fixed)
        # if (not movies or any(len(movie['text']) < len(text) for movie in movies)) and type in ['movies', "all"]:  # If no movies or partial matches were found
        if not movies and type in ['movies', "all"]:  # If no movies or partial matches were found
            print("Running fuzzy matching for movies")
            fuzzy_movie = self.fuzzy_match_entity(text, self.entities)
            if fuzzy_movie and fuzzy_movie not in [movie['text'] for movie in movies]:
                movies.append({'text': fuzzy_movie, 'start': None, 'end': None})

        # if (not relations or any(len(relation['text']) < len(text) for relation in relations)) and type in ['relations', "all"]:  # If no relations or partial matches were found
        if not relations and type in ['relations', "all"]:  # If no relations or partial matches were found
            print("Running fuzzy matching for relations")
            fuzzy_relation = self.fuzzy_match_entity(text, self.relations)
            if fuzzy_relation and fuzzy_relation not in [relation['text'] for relation in relations]:
                relations.append({'text': fuzzy_relation, 'start': None, 'end': None})

        # Return only the text values
        return {
            "movies": [movie['text'] for movie in movies],
            "relations": [relation['text'] for relation in relations]
        }

    def filter_overlapping_matches(self, entities):
        # Entities is a list of dicts with 'text', 'start', 'end'
        # We will sort entities by length (longest first), and keep an entity only if it doesn't overlap with any already kept entities
        entities = sorted(entities, key=lambda x: len(x['text']), reverse=True)
        kept_entities = []

        for entity in entities:
            overlaps = False
            for kept_entity in kept_entities:
                # If the entities have positions, check for overlap
                if entity['start'] is not None and kept_entity['start'] is not None:
                    if self.spans_overlap(entity['start'], entity['end'], kept_entity['start'], kept_entity['end']):
                        overlaps = True
                        break
                else:
                    # If positions are None (from fuzzy matching), check if entity text is substring of kept entity text
                    if entity['text'] in kept_entity['text']:
                        overlaps = True
                        break
            if not overlaps:
                kept_entities.append(entity)
        return kept_entities

    def spans_overlap(self, start1, end1, start2, end2):
        # Return True if the spans [start1, end1) and [start2, end2) overlap
        return max(start1, start2) < min(end1, end2)

    def display_loaded_entities(self):
        # Display all entities from the loaded spaCy model using the EntityRuler
        print("Entities in the loaded model:")
        if "entity_ruler" in self.nlp.pipe_names:
            ruler = self.nlp.get_pipe("entity_ruler")
            for pattern in ruler.patterns:
                print(f"- Label: {pattern['label']}, Pattern: {pattern['pattern']}")