import random
from abc import ABC, abstractmethod
import logging

from app.services.embeddings import Embeddings
from app.services.extractors.movie_extraction import MovieExtractor
from app.services.extractors.relationship_extraction import RelationshipExtractor
from app.services.sparql_graph import SPARQLGraph

logger = logging.getLogger(__name__)

class AnsweringService(ABC):
    @abstractmethod
    def __init__(self):
        pass

    @abstractmethod
    def get_response(self, message: str) -> str:
        pass


class SPARQLAnswerService(AnsweringService):
    def __init__(self, sparql_graph: SPARQLGraph):
        self.sparql_graph: SPARQLGraph = sparql_graph

    def get_response(self, query: str) -> str:
        """Use the SPARQLGraph to execute a query and return the response."""
        return self.sparql_graph.execute_query(query)


class EmbeddingAndKnowledgeAnswerService(AnsweringService):
    def __init__(self, sparql_graph: SPARQLGraph, embeddings: Embeddings):
        self.sparql_graph: SPARQLGraph = sparql_graph
        self.embeddings: Embeddings = embeddings
        self.movie_extractor = MovieExtractor()
        self.relationship_extractor = RelationshipExtractor()
        self.answering_service = SPARQLAnswerService(self.sparql_graph)

    def get_response(self, message: str) -> str:
        """Extract entities from the message and query the SPARQL graph."""
        # TODO implement a safety mechanisms when one of them is none or it fails, then run the embeddings based

        message = clean_query(message)

        # 1) extract entities, then remove the entity from the message
        entities = self.movie_extractor.extract(message)
        if len(entities) == 0:
            return "I could not find any entity in your message, please try again and reformulate."
        if len(entities) > 1:
            return "I found multiple entities in your message, please try again and ask about one movie only!"

        entity_label = entities[0]
        message = message.replace(entity_label, "")

        # 2) extract relation
        relations = self.relationship_extractor.extract(message)
        if len(relations) == 0:
            return "I could not find any relation in your message, please try again and reformulate."
        if len(relations) > 1:
            return "I found multiple relations in your message, please try again and ask about one relation only!"

        relation_label = relations[0]

        # print(f"Movie: {entity_label}, Relation: {relation_label}")
        logging.info(f"Movie: {entity_label}, Relation: {relation_label}")

        # Get entity for object and relation
        entity = self.sparql_graph.get_id_for_movie(entity_label).split("/")[-1]
        relation = self.sparql_graph.get_rel_for_lbl(relation_label).split("/")[-1]

        # print(f"Movie: {entity}, Relation: {relation}")
        logging.info(f"Movie: {entity}, Relation: {relation}")

        # 3) Query the graph and return if we have an answer
        answer_graph = self.get_answer_from_graph(entity, relation)
        if answer_graph:
            return make_human_response(entity_label, relation_label, answer_graph)

        # 4) If we don't have an answer from the graph, try embeddings
        answer_embeddings = self.get_answer_from_embeddings(entity, relation)
        if answer_embeddings:
            return make_human_response(entity_label, relation_label, answer_embeddings, from_embeddings=True)

        return ("I could not find an answer to your question or calculate it from the embeddings. Please try "
                "rephrasing and ask again.")

    def get_answer_from_graph(self, entity: str, relation: str) -> str:
        query = f"""PREFIX wd: <http://www.wikidata.org/entity/>
                    PREFIX wdt: <http://www.wikidata.org/prop/direct/>
                    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                    SELECT ?answerLabel
                    WHERE {{
                        wd:{entity} wdt:{relation} ?answer .
                        BIND(IF(ISLITERAL(?answer), ?answer, ?answerLabel) AS ?answerLabel)
                        OPTIONAL {{
                            ?answer rdfs:label ?answerLabel .
                            FILTER(LANG(?answerLabel) = "en")
                        }}
                    }}
                    LIMIT 1"""

        response = self.sparql_graph.execute_query(query)
        return response

    def get_answer_from_embeddings(self, entity: str, relation: str) -> str:
        response = self.embeddings.calculate_embeddings(entity, relation)
        response = self.sparql_graph.get_lbl_for_ent(response)

        if response == "Unknown Label":
            return ""

        return response


def clean_query(query: str) -> str:
    # remove_chars = ["?", ".", ",", "!", "(", ")", "[", "]", "{", "}", ";"]
    # for now remove only punctuation as they are also in movie names and important
    remove_chars = ["?", ".", ",", "!", "\"", "'"]
    for char in remove_chars:
        query = query.replace(char, "")

    # replace multiple spaces with a single space
    query = " ".join(query.split())
    # trim
    query = query.strip()

    return query


def make_human_response(entity: str, relation: str, prediction: str, from_embeddings: bool = False) -> str:
    # if prediction has format yyyy-mm-dd, convert it to a year only
    if len(prediction) == 10 and prediction[4] == "-" and prediction[7] == "-":
        prediction = prediction[:4]

    arr = [f"I think it is {prediction}.",
           f"That is a good question, I think that the answer is {prediction}.",
           f"As far as I know, it is {prediction}.",
           f"I would say that it is {prediction}.",
           f"According to my knowledge, it is {prediction}.",
           f"I'm almost certain that it is {prediction}.",

           # more fancy sentences -> they might not work all the time
           f"The {relation} is {prediction} for {entity}.",
           f"I think that the {relation} is {prediction} for {entity}.",
           f"I would say that the {relation} of {entity} is {prediction}.", ]

    # do a random choice
    return f"{random.choice(arr)}{" (Embedding Answer)" if from_embeddings else ""}"
