import asyncio
import sys
import time
from typing import List
import logging

from fastapi import FastAPI
from speakeasypy import Chatroom, Speakeasy  # installed as wheel

from app.config.app import settings
from app.config.enums import Environment, Milestone
from app.services.answering_service import AnsweringService, EmbeddingAndKnowledgeAnswerService, SPARQLAnswerService
from app.services.embeddings import Embeddings
from app.services.sparql_graph import SPARQLGraph

# Logging setup
def setup_logging(log_file=f'app.{str(settings.environment.value)}.log'):
    logging.basicConfig(
        level=logging.DEBUG if settings.environment == Environment.DEV else logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.StreamHandler(),  # Console output
            logging.FileHandler(log_file)  # File output
        ]
    )

# Initialize logging
setup_logging()
logger = logging.getLogger(__name__)

app = FastAPI()

answering_service: AnsweringService


class Agent:
    def __init__(self, username: str, password: str, _answering_service: AnsweringService):
        self.username = username
        self.speakeasy = Speakeasy(host=settings.default_host_url, username=username, password=password)
        self.speakeasy.login()
        self.answering_service = _answering_service

    async def listen(self):
        while True:
            rooms: List[Chatroom] = self.speakeasy.get_rooms(active=True)
            for room in rooms:
                if not room.initiated:
                    room.post_messages(f'Hello {room.user_aliases[0]}! This is a welcome message from {room.my_alias}.')
                    room.initiated = True

                for message in room.get_messages(only_partner=True, only_new=True):
                    print(f"\t- Chatroom {room.room_id} "
                          f"- new message #{message.ordinal}: '{message.message}' "
                          f"- {self.get_time()}")
                    
                    logger.info(f"Received message: {message.message}")

                    message_str = None
                    
                    if self.is_welcome_message(message.message):
                        message_str = "Hello! Nice to have you here. I can answer multiple questions regarding movies. Let's start!"

                    if self.is_end_message(message.message):
                        message_str = "Goodbye! I hope I was able to help you. Feel free to come back anytime."

                    if not message_str:
                        message_str = self.answering_service.get_response(message.message)
                    
                    room.post_messages(message_str)
                    room.mark_as_processed(message)

                    logging.info(f"Response: {message_str}")

                for reaction in room.get_reactions(only_new=True):
                    print(f"\t- Chatroom {room.room_id} "
                          f"- new reaction #{reaction.message_ordinal}: '{reaction.type}' "
                          f"- {self.get_time()}")
                    # Your agent logic here
                    room.post_messages(f"Received your reaction: '{reaction.type}' ")
                    room.mark_as_processed(reaction)

            await asyncio.sleep(settings.listen_freq)

    def is_welcome_message(self, message: str) -> bool:
    # Expanded list of possible greetings
        greetings = [
            "hi", "hello", "hey", "greetings", "heyo", "hallo", "hi there", "hello there", "hey there", 
            "morning", "good morning", "hiya", "what's up", "sup", "yo", "howdy", "good day", 
            "good afternoon", "good evening", "evening", "g'day", "salutations"
        ]
        
        # Clean the message for consistent checking
        message_cleaned = message.lower().strip()

        # Check if any greeting matches and is short enough relative to the full message
        for greeting in greetings:
            greeting_cleaned = greeting.lower()
            
            if message_cleaned.startswith(greeting_cleaned) and len(greeting_cleaned) * 2 >= len(message_cleaned):
                return True
                
        return False

    def is_end_message(self, messages: str) -> bool:
        matches = ["bye", "goodbye", "farewell", "adios", "ciao", "later", "see you", "talk to you later", "ttyl", "goodnight", "night", "sleep", "rest" \
                    "alright thanks", "alright thank you", "thanks", "thank you", "ok thanks", "ok thank you", "okay thanks", "okay thank you", "ok bye", "okay bye", "ok goodbye", "okay goodbye"]
        cleaned_messages = messages.lower().strip()
        for match in matches:
            ending_cleaned = match.lower()
            if cleaned_messages.startswith(ending_cleaned) and len(ending_cleaned) * 2 >= len(cleaned_messages):
                return True
        
        return False
            

    @staticmethod
    def get_time() -> str:
        return time.strftime("%H:%M:%S, %d-%m-%Y", time.localtime())


@app.on_event("startup")
async def startup_event():
    global answering_service

    print(f"Starting up in mode: {settings.environment}")

    # lazy load only in dev to make loading faster
    sparql_graph = SPARQLGraph(settings.environment, lazy_load=settings.environment != Environment.PROD)
    embeddings = Embeddings(settings.environment, lazy_load=settings.environment != Environment.PROD)

    if settings.milestone == Milestone.ONE:
        answering_service = SPARQLAnswerService(sparql_graph)
    elif settings.milestone == Milestone.TWO:
        answering_service = EmbeddingAndKnowledgeAnswerService(sparql_graph, embeddings)
    elif settings.milestone == Milestone.THREE:
        raise NotImplementedError("Milestone 3 not implemented yet")
    else:  # Final Project
        raise NotImplementedError("Final Project not implemented yet")

    agent_instance = Agent(settings.bot_username, settings.bot_password, answering_service)
    asyncio.create_task(agent_instance.listen())


@app.get("/")
def read_root():
    return {"message": "Welcome to the Chatbot!"}


@app.get("/milestone1")
def read_root():
    message = """PREFIX ddis: <http://ddis.ch/atai/>
                 PREFIX wd: <http://www.wikidata.org/entity/>
                 PREFIX wdt: <http://www.wikidata.org/prop/direct/>
                 PREFIX schema: <http://schema.org/>
                 SELECT ?lbl WHERE {
                     ?movie wdt:P31 wd:Q11424 .
                     ?movie ddis:rating ?rating .
                     ?movie rdfs:label ?lbl .
                 }
                 ORDER BY DESC(?rating)
                 LIMIT 1"""

    return answering_service.get_response(message)


@app.get("/milestone2/{message}")
def read_root(message: str):
    return answering_service.get_response(message)
