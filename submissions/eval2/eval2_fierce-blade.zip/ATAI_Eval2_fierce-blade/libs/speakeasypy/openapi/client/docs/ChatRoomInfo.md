# ChatRoomInfo


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**assignment** | **bool** |  | 
**form_ref** | **str** |  | 
**uid** | **str** |  | 
**remaining_time** | **int** |  | 
**user_aliases** | **[str]** |  | 
**alias** | **str** |  | 
**prompt** | **str** |  | 
**mark_as_no_feedback** | **bool** |  | 
**start_time** | **int** |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


