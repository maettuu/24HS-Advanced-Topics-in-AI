# how to run this project

# login to website
https://speakeasy.ifi.uzh.ch/

request chat with `fierce-blade`

# Local steps:
- change your shell to your environment (conda, venv, etc)
- `poetry install` to install dependencies and create environment
- `uvicorn app.main:app --reload` to run the project

# To download dataset
- run `python ./utils/download_dataset.py` to download the dataset

# For "production" - preloads everything
- `uvicorn app.main:app`


# Current extractor approach
- We have an NLP query
    - We remove the question mark
    1) Movie Extractor 
        - 1. Extract with NLTK with levhenstein distance for most similar words (with hypens variations if they exist)
        - 1a If no match was found, we extract with fuzzy matcher (maximally one movie will be returned on this point right now)
        - 2. it is theoretically possible to run NER on movies and then fuzzy match them against the extracted movie names but too much work
            - it would work good when we want to extract all movies from a text but nltk with better algo could solve thiss as well
    2) Relationship extractor
        - 1. Manual extraction (like publication date which is weird)
        - 2. Extract with NLTK with levhenstein distance for most similar words (works perfectly for directors and similar)
            - 2a. Extract with fuzzy matcher (maximally one movie will be returned on this point right now - but not that good for relations)
        - 3. Run embedding search
            - Take all relations and embedd them into space
            - take the query without movie remove all stopwords and embedd it, hopefully we get some relationships


# 2nd evaulation - Example queries
- `Who directed the movie "The Matrix"?`
- `What is the genre of the movie "The Matrix"?`
- `What is the publication date of the movie "The Matrix"?`
- `What is the duration of the movie "The Matrix"?`

# 3rd movies evaulation
- images in testing dataset
- `Show me an Picture of Atli Oskar Fjalarsson`

# Movies extraction
- Find all persons (all people with relation is a person) Q5
- Find all movies and their imdb titles?
- Find all personst and their imdb identificators - then query the movies with the imdb identificator

# Atai dataset link
https://files.ifi.uzh.ch/ddis/teaching/ATAI2024/dataset/


# Changelog
28.10.2024
- Processed movienet json to an better structure (key: casts)
    - I ignored every images, that have 2 persons
- Extracted all Humans from KG, and retrained NLTK NER on it with new label person
- Created pipeline which can extract person from a sentence, find the proper imdb_id and then find an random image

29.10.2024
- Question Classifier created
    - Trained on GPT generated examples, SentenceBert with trained simple linear regression to determine that is it
    - Why? it is more flexible, and they are still setnences, might require much more data and they are somehow repetitive 

04.11.2024
- Question classifier implemented in main.py
- Optimalized SPACY loading (only one instance exists)

10.11.2024
- Person image finder implemented
- The person is determines with NER, afterwards the person is searched in the KG and the imdb ID is retrieved
- given an IMDB ID, given custom lookup array (imdb ID to all en)

13.11.2024
- Question classifier - new structure implemented (sentence Transformer + custom NN) for classification
    - This achieves much better accuracy mainly when movies are part of the sentence
- Adapted repository structure
    - New Agent Answering Service - which is responsible for answering the questions (easily to reuse in ipynbs)
    - Loading moved from main loop into agent service
- Improved NER for movies, persons and relation
    - Movies are extracted on lowercase inputs right now
    - firstly an NLTK match is used, afterwards  a fuzzy match is used
    - the final extraction is an combination of both of them based on a longest match on a place -> we can return multiple instances




# What needs to be done
- recommendations S3
- Crowdsourcing S4
- Improved extraction of relations S3/S2
- Improved LLM prompting S3/S4
- Get all entities under one relation - when there are multiple entities under one relation S3

# What could be done
- Answering of extended questions 
    - given that I like movies with XY suggest me something
    - Match harry Potter when it is a partial movie
    - Answer the highest/lowest rated movies
    - Get all movies where XY played
    - Get all movies where XY directed etc