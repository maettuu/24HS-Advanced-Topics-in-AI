import nltk

nltk.download('stopwords')
nltk.download('punkt_tab')
