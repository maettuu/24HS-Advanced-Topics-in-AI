import logging
import random
import re
from abc import ABC, abstractmethod

from app.config.app import settings
from app.services.embeddings_service import EmbeddingsService
from app.services.extractors.movie_extraction import MovieExtractor
from app.services.extractors.relationship_extraction import RelationshipExtractor
from app.services.llm_service import LlmService
from app.services.sparql_graph import SPARQLGraph
from app.services.extractors.main import SpacyExtractor
from app.services.answering_service import AnsweringService, SPARQLAnswerService

logger = logging.getLogger(__name__)

class EmbeddingAndKnowledgeAnswerService(AnsweringService):
    def __init__(self, sparql_graph: SPARQLGraph, embeddings: EmbeddingsService, spacy_extractor: 'SpacyExtractor'=None):
        self._sparql_graph: SPARQLGraph = sparql_graph
        self._embeddings: EmbeddingsService = embeddings
        self._llm = LlmService()
        self._movie_extractor = MovieExtractor(spacy_extractor=spacy_extractor)
        self._relationship_extractor = RelationshipExtractor(spacy_extractor=spacy_extractor)
        self._answering_service = SPARQLAnswerService(self._sparql_graph)

    def get_response(self, message: str) -> str:
        """Extract entities from the message and query the SPARQL graph."""
        # TODO implement a safety mechanisms when one of them is none or it fails, then run the embeddings based

        idx, message = extract_and_remove_potential_idx(message)
        clean_message = clean_query(message)

        # 1) extract entities, then remove the entity from the message
        entities = self._movie_extractor.extract(clean_message)
        if len(entities) == 0:
            return "I could not find any entity in your message, please try again and reformulate."
        if len(entities) > 1:
            return "I found multiple entities in your message, please try again and ask about one movie only!"

        entity_label = entities[0]
        clean_message = clean_message.replace(entity_label, "")

        # 2) extract relation
        relations = self._relationship_extractor.extract(clean_message)
        if len(relations) == 0:
            return "I could not find any relation in your message, please try again and reformulate."
        if len(relations) > 1:
            return "I found multiple relations in your message, please try again and ask about one relation only!"

        relation_label = relations[0]

        # print(f"Movie: {entity_label}, Relation: {relation_label}")
        logging.info(f"Movie: {entity_label}, Relation: {relation_label}")

        # Get entity for object and relation
        # entity = self._sparql_graph.get_id_for_movie(entity_label, idx).split("/")[-1]
        entity_uris = self._sparql_graph.get_id_for_movie(entity_label, idx)
        entity = entity_uris[0].split("/")[-1]
        relation = self._sparql_graph.get_rel_for_lbl(relation_label).split("/")[-1]

        if len(entity_uris) == 1:
            return self.get_answer_and_make_response(entity, relation, entity_label, relation_label)
        else:
            entity_descriptions = []
            for entity in entity_uris:
                answer_graph = self.get_answer_from_graph(entity.split("/")[-1])
                if answer_graph:
                    entity_descriptions.append(answer_graph)
            # only single or no description found, try to execute normally with first uri
            if len(entity_descriptions) < 2:
                return self.get_answer_and_make_response(entity, relation, entity_label, relation_label)
            return make_human_response_with_descriptions(message, entity_descriptions)

    def get_answer_and_make_response(self, entity: str, relation: str, entity_label: str, relation_label: str) -> str:
        # print(f"Movie: {entity}, Relation: {relation}")
        logging.info(f"Movie: {entity}, Relation: {relation}")

        # 3) Query the graph and return if we have an answer
        answer_graph = self.get_answer_from_graph(entity, relation)
        if answer_graph:
            return self.make_human_response(entity_label, relation_label, answer_graph)

        # 4) If we don't have an answer from the graph, try embeddings
        answer_embeddings = self.get_answer_from_embeddings(entity, relation)
        if answer_embeddings:
            return self.make_human_response(entity_label, relation_label, answer_embeddings, from_embeddings=True)

        return ("I could not find an answer to your question or calculate it from the embeddings. Please try "
                "rephrasing and ask again.")

    def get_answer_from_graph(self, entity: str, relation: str = None) -> str:
        if relation:
            query = f"""PREFIX wd: <http://www.wikidata.org/entity/>
                        PREFIX wdt: <http://www.wikidata.org/prop/direct/>
                        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                        SELECT ?answerLabel
                        WHERE {{
                            wd:{entity} wdt:{relation} ?answer .
                            BIND(IF(ISLITERAL(?answer), ?answer, ?answerLabel) AS ?answerLabel)
                            OPTIONAL {{
                                ?answer rdfs:label ?answerLabel .
                                FILTER(LANG(?answerLabel) = "en")
                            }}
                        }}
                        LIMIT 1"""
        else:
            query = f"""PREFIX wd: <http://www.wikidata.org/entity/>
                        PREFIX schema: <http://schema.org/>
                        SELECT ?description
                        WHERE {{
                            OPTIONAL {{
                                wd:{entity} schema:description ?description .
                                FILTER(LANG(?description) = "en")
                            }}
                        }}
                        LIMIT 1"""

        response = self._sparql_graph.execute_query(query)
        return response

    def get_answer_from_embeddings(self, entity: str, relation: str) -> str:
        response = self._embeddings.calculate_embeddings(entity, relation)
        response = self._sparql_graph.get_lbl_for_ent(response)

        if response == "Unknown Label":
            return ""

        return response

    def make_human_response(self, entity: str, relation: str, prediction: str, from_embeddings: bool = False) -> str:
        # if prediction has format yyyy-mm-dd, convert it to a year only
        if len(prediction) == 10 and prediction[4] == "-" and prediction[7] == "-":
            prediction = prediction[:4]

        arr = [f"I think it is {prediction}.",
               f"That is a good question, I think that the answer is {prediction}.",
               f"As far as I know, it is {prediction}.",
               f"I would say that it is {prediction}.",
               f"According to my knowledge, it is {prediction}.",
               f"I'm almost certain that it is {prediction}.",

               # more fancy sentences -> they might not work all the time
               f"The {relation} is {prediction} for {entity}.",
               f"I think that the {relation} is {prediction} for {entity}.",
               f"I would say that the {relation} of {entity} is {prediction}.", ]

        if settings.use_llm:
            try:
                answer = self._llm.beautify_answer(f"The {relation} of {entity} is {prediction}.")
            except:  # Just in case the LLM service fails
                answer = random.choice(arr)
        else:
            answer = random.choice(arr)

        # do a random choice
        return f'{answer}{" (Embedding Answer)" if from_embeddings else ""}'


def make_human_response_with_descriptions(message: str, descriptions: list[str]) -> str:
    human_response = "Oh! It seems there are several entries for the movie you asked for:\n"
    for idx, desc in enumerate(descriptions, start=1):
        human_response += f"{{{idx}}} {desc}\n"
    human_response += "If you\'d like to know more about a specific movie please ask using the corresponding index.\n" \
                      f'Here\'s an example: "{{1}} {message}"'

    return human_response


def clean_query(query: str) -> str:
    # Replace multiple spaces with a single space
    query = " ".join(query.split())
    # Trim leading and trailing spaces
    query = query.strip()

    # List of characters to remove if they are the last character in the query
    remove_chars = ["?", ".", ",", "!", "\"", "'"]

    # Remove the last character if it is in the list of remove_chars
    if query and query[-1] in remove_chars:
        query = query[:-1]

    return query


def extract_and_remove_potential_idx(query: str) -> tuple[int | None, str]:
    # search query for {int}
    match = re.search(r"\{(\d+)\}", query)
    if match:
        idx = int(match.group(1)) - 1  # numbering starts with 1, for indices has to be subtracted
        # remove {int} from query plus any following whitespaces
        query_without_idx = re.sub(r"\{\d+\}\s?", "", query).strip()
        return idx, query_without_idx
    return None, query