
from app.services.sparql_graph import SPARQLGraph
from app.services.answering_service import AnsweringService
from app.services.extractors.main import SpacyExtractor

import random
import os
from app.config.app import settings
import json
import time
import re


class PersonImageFinder(AnsweringService):

    # init with sparql graph
    def __init__(self, sparql_graph: SPARQLGraph, spacy_extractor: SpacyExtractor):
        self.sparql_graph: SPARQLGraph = sparql_graph
        self.spacy_extractor: SpacyExtractor = spacy_extractor

        self.imdb_to_images = {}
        self._load_metadata()
        

    def _load_metadata(self):
        start_time = time.time()
        
        # load the json into a dictionary
        self.metadata_path = os.sep.join((settings.utils_path, "too_large_dataset", "movienet"))
        with open(os.path.join(self.metadata_path, 'structured_cast_images.json'), 'r') as file:
            self.imdb_to_images = json.load(file)
        
        end_time = time.time()
        print(f"Metadata loaded in {end_time - start_time} seconds")

    def get_image_for_imdb_id(self, imdb_id: str):
        """This works only for person as data are preprocessed like that"""
        if imdb_id not in self.imdb_to_images.keys():
            # TODO add exception and catch it on the main response
            print(f"No images found for IMDb ID: {imdb_id}")
            return None
        
        images = self.imdb_to_images[imdb_id]
        # get random image
        return random.choice(images)
    
    def get_response(self, message: str) -> str:
        idx, message = extract_and_remove_potential_idx(message)
        # extract the person entity from message
        entities = self.spacy_extractor.get_entities_with_fuzzy_matching(message, 'person')
        if not entities.get("people") or not entities["people"]:
            return "I'm sorry, but there was no person found in the message."

        if len(entities["people"]) > 1:
            return "I'm sorry, but I can show you only a picture of one person at a time."
        
        person_string = entities["people"][0]
        print("Person string: ", person_string)

        imdb_id = self.get_person_imdb_id(person_string, idx)
        if imdb_id is None:
            return "I'm sorry, but this person is most probably not an actor, so we don't have an image."
        if isinstance(imdb_id, str):
            print("IMDb ID: ", imdb_id)

            random_image = self.get_image_for_imdb_id(imdb_id)
            if random_image is None:
                return "We are sorry, but I can show you only a picture of one person, and no image was found for this person."

            print(random_image)

            return self._format_answer(random_image, person_string)
        elif isinstance(imdb_id, list):
            return make_human_response_with_descriptions(message, imdb_id)
    
    def _format_answer(self, random_image_str: str, person_string: str):
        #remove after the last dot
        random_image_str = random_image_str.split(".")[0]

        templates = [
            f"image:{random_image_str} There is an image of {person_string}, enjoy!",
            f"image:{random_image_str} Here is an image of {person_string} for you!",
            f"image:{random_image_str} This is a picture of {person_string}.",
            f"image:{random_image_str} Enjoy this image of {person_string}.",
            f"image:{random_image_str} Here is a picture of {person_string}.",
            f"image:{random_image_str} This is a photo of {person_string}.",
            f"image:{random_image_str} Take a look at this wonderful image of {person_string}!",
            f"image:{random_image_str} Feast your eyes on this picture of {person_string}.",
            f"image:{random_image_str} Here's a fantastic shot of {person_string}, just for you!",
            f"image:{random_image_str} Behold this captivating image of {person_string}!",
            f"image:{random_image_str} Hope you enjoy this striking photo of {person_string}.",
            f"image:{random_image_str} Check out this amazing picture of {person_string}.",
            f"image:{random_image_str} Here's a stunning photo of {person_string} to enjoy!",
            f"image:{random_image_str} Here's an impressive snapshot of {person_string}.",
            f"image:{random_image_str} Take a moment to appreciate this photo of {person_string}.",
            f"image:{random_image_str} Look at this beautiful picture of {person_string}!"
        ]

        # return random template
        return random.choice(templates)

    def get_person_imdb_id(self, person: str, idx: int):
        # Get the URI of the person using an internal function
        entity_uris = self.sparql_graph.get_id_for_person(person, idx)
        entity = entity_uris[0].split("/")[-1]
        if entity == "Unknown ID":
            print(f"No URI found for person: {person}")
            return None

        if len(entity_uris) == 1:
            return self.get_imdb_id(entity, person)
        else:
            entity_descriptions = []
            for entity in entity_uris:
                query = f"""PREFIX wd: <http://www.wikidata.org/entity/>
                            PREFIX schema: <http://schema.org/>
                            SELECT ?description
                            WHERE {{
                                OPTIONAL {{
                                    wd:{entity.split("/")[-1]} schema:description ?description .
                                    FILTER(LANG(?description) = "en")
                                }}
                            }}
                            LIMIT 1"""
                response = self.sparql_graph.execute_query(query)
                if response:
                    entity_descriptions.append(response)
            # only single or no description found, try to execute normally with first uri
            if len(entity_descriptions) < 2:
                return self.get_imdb_id(entity, person)
            return entity_descriptions

    def get_imdb_id(self, entity: str, person: str):
        print(f"Entity found for person: {person} is {entity}")

        # Construct the SPARQL query to retrieve IMDb ID
        query = f"""PREFIX wd: <http://www.wikidata.org/entity/>
                    PREFIX wdt: <http://www.wikidata.org/prop/direct/>
                    SELECT ?imdb_id
                    WHERE {{
                        wd:{entity} wdt:P345 ?imdb_id .
                    }}
                """

        # Execute the query and capture the response
        response = self.sparql_graph.execute_query(query)
        print("Response: ", response)

        # !! response is always string if we use execute query
        if isinstance(response, str):
            return response

        print(f"No IMDb ID found for person: {person}")
        return None


def make_human_response_with_descriptions(message: str, descriptions: list[str]) -> str:
    human_response = "Oh! It seems there are several entries for the person you asked for:\n"
    for idx, desc in enumerate(descriptions, start=1):
        human_response += f"{{{idx}}} {desc}\n"
    human_response += "If you\'d like to know more about a specific person please ask using the corresponding index.\n" \
                      f'Here\'s an example: "{{1}} {message}"'

    return human_response


def extract_and_remove_potential_idx(query: str) -> tuple[int | None, str]:
    # search query for {int}
    match = re.search(r"\{(\d+)\}", query)
    if match:
        idx = int(match.group(1)) - 1  # numbering starts with 1, for indices has to be subtracted
        # remove {int} from query plus any following whitespaces
        query_without_idx = re.sub(r"\{\d+\}\s?", "", query).strip()
        return idx, query_without_idx
    return None, query
