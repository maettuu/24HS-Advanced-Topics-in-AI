from app.config.app import settings
from app.config.enums import Environment
from app.services.extractors.main import SpacyExtractor
from app.services.extractors.movie_extraction import MovieExtractor
from app.services.llm_service import LlmService
from app.services.sparql_graph import SPARQLGraph


class RecommendationService:
    def __init__(self, sparql_graph: SPARQLGraph, env: Environment = settings.environment, lazy_load=False,
                 spacy_extractor: SpacyExtractor = None):
        self._sparql_graph = sparql_graph
        self._movie_extractor = MovieExtractor(spacy_extractor=spacy_extractor)

        # # Load embeddings if not lazy loading
        # if not lazy_load:
        #     self._load_data()

    def _load_data(self):
        """Load data on initialization."""
        pass

    def get_response(self, message: str) -> str:
        # 1) extract entities, then remove the entity from the message
        movie_names = self._movie_extractor.extract(message)
        if len(movie_names) == 0:
            return "I could not find any entity in your message, please try again and reformulate."

        movie_ids: list[str] = []
        for movie_name in movie_names:
            movie_id = self._sparql_graph.get_ent_for_lbl(movie_name).split("/")[-1]
            if movie_id == "Unknown ID":
                return f"I don't know the movie {movie_name}. Try something else."
            else:
                movie_ids.append(movie_id)


        # Get the URI of the person using an internal function
        entity_uris = self._sparql_graph.get_id_for_movie()
        entity = entity_uris[0].split("/")[-1]
        if entity == "Unknown ID":
            print(f"No URI found for person: {person}")
            return None

        if len(entity_uris) == 1:
            return self.get_imdb_id(entity, person)

        answer = self._attribute_based_recommendation(movie_ids, designated_attributes=True)
        if answer:
            return self._make_human_anser(answer)

        answer = self._attribute_based_recommendation(movie_ids, designated_attributes=False)
        if answer:
            return self._make_human_anser(answer)

        answer = self._genre_based_recommendation(movie_ids[0])
        if answer:
            return self._make_human_anser(answer)

        return f"There is no movie worthy of {", ".join(movie_names)} to be recommended."

    def _attribute_based_recommendation(self, movie_ids, designated_attributes: bool) -> str:
        if len(movie_ids) < 2:
            return ""

        # Get common attributes of the movies
        common_attributes = self._get_common_attributes(movie_ids, designated_attributes=designated_attributes)
        if len(common_attributes) == 0:
            return ""

        print("2.2 common attributes: ", common_attributes)  # Debugging

        # Get a movie with the same attributes
        response = self._get_movie_with_attributes(movie_ids, common_attributes)

        if "Unknown Label" in response:
            return ""

        return response

    def _get_common_attributes(self, movie_ids, designated_attributes: bool) -> dict:
        movie_attributes = []
        print("1.0. movie_ids: ", movie_ids)  # Debugging
        for movie_id in movie_ids:
            """Queries the knowledge graph to get all attributes and values for a specific movie."""
            query = f"""PREFIX wd: <http://www.wikidata.org/entity/>
                        PREFIX wdt: <http://www.wikidata.org/prop/direct/>
                        SELECT ?property ?value
                        WHERE {{
                            {"VALUES ?property {wdt:P136 wdt:P57 wdt:P179}" if designated_attributes else ""}
                            wd:{movie_id} ?property ?value .
                        }}"""

            try:
                results = self._sparql_graph.execute_query_plain_answer(query)
                attributes = {}
                for result in results:
                    property_, value = result
                    if property_ and value:
                        attributes[property_] = value
            except Exception as e:
                print(f"Error querying the graph: {e}")
                return {}

            movie_attributes.append(attributes)

        print("1.1. movie_attributes: ", movie_attributes)  # Debugging

        # Start with the attributes and values of the first movie
        common_attributes = movie_attributes[0]

        print("2.0. common attributes: ", movie_attributes)  # Debugging
        # Iterate over the remaining movies
        for attributes in movie_attributes[1:]:
            print("2.1 common attributes: ", attributes)  # Debugging
            # Keep only attributes that exist in the current movie and have the same value
            common_attributes = {attr: value for attr, value in common_attributes.items() if
                                 attr in attributes and attributes[attr] == value and "http" in value}

        return common_attributes

    def _get_movie_with_attributes(self, movie_ids, common_attributes) -> str:
        # Construct SPARQL filters with proper handling for IRIs and literals
        filters = "\n".join(f"?movie <{attr}> <{value}> ." for attr, value in common_attributes.items())
        query = f"""PREFIX wd: <http://www.wikidata.org/entity/>
                    SELECT ?movie
                    WHERE {{
                        {filters}
                        FILTER (?movie NOT IN ({", ".join(["wd:" + item for item in movie_ids])}))
                    }}
                    LIMIT 1"""

        print(f"3 Query to get movies with common attributes:\n{query}")  # Debugging
        response = self._sparql_graph.execute_query(query)

        print("4 final response query", response)
        for item in response.split("\n"):
            print("5 ITEM: ", item)
        response_lbls = ", ".join([self._sparql_graph.get_lbl_for_ent(item) for item in response.split("\n") if item])
        print("6 final shit Response:", response_lbls)  # Print response for debugging

        if response_lbls == "Unknown Label":
            return ""

        return response_lbls

    def _genre_based_recommendation(self, movie_id) -> str:
        """Queries the knowledge graph to get all attributes and values for a specific movie."""
        query = f"""PREFIX wd: <http://www.wikidata.org/entity/>
                    PREFIX wdt: <http://www.wikidata.org/prop/direct/>
                    SELECT ?value
                    WHERE {{
                        wd:{movie_id} wdt:P136 ?value .
                    }}"""
        print("10: query", query)
        genre = self._sparql_graph.execute_query(query)
        print("11 genre:", genre)
        genre = genre.split("/")[-1]

        if genre == "":
            return ""

        query = f"""PREFIX wd: <http://www.wikidata.org/entity/>
                    PREFIX wdt: <http://www.wikidata.org/prop/direct/>
                    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                    SELECT ?movieLabel
                    WHERE {{
                        ?movie wdt:P136 wd:{genre} .
                        BIND(IF(ISLITERAL(?movie), ?movie, ?movieLabel) AS ?movieLabel)
                        OPTIONAL {{
                            ?movie rdfs:label ?movieLabel .
                            FILTER(LANG(?movieLabel) = "en")
                        }}
                    }}
                    LIMIT 1"""

        print("12: query", query)

        movie = self._sparql_graph.execute_query(query)
        print("13 movie", movie)
        return movie

    def _make_human_anser(self, message: str) -> str:
        if settings.use_llm:
            try:
                return LlmService().beautify_answer(message)
            except Exception as e:
                print(f"Error in LLM: {e}")

        return f"I recommend you to watch {message}."
