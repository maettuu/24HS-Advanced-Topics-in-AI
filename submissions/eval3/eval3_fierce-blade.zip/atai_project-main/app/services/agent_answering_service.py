import logging

from app.config.app import settings
from app.config.enums import Environment, Milestone
from app.services.embeddings_service import EmbeddingsService
from app.services.extractors.main import SpacyExtractor
from app.services.knowledge_answering_service import EmbeddingAndKnowledgeAnswerService
from app.services.llm_service import LlmService
from app.services.person_image_finder import PersonImageFinder
from app.services.question_classifier import QuestionCategory, QuestionClassifier
from app.services.recommendation_service import RecommendationService
from app.services.sparql_graph import SPARQLGraph

logger = logging.getLogger(__name__)



class AgentAnsweringService:
    def __init__(self, environment: Environment = settings.environment):
        print("Initializing AgentAnsweringService with environment: ", environment)
        lazy_load = environment != Environment.PROD
        sparql_graph = SPARQLGraph(environment, lazy_load)
        embeddings = EmbeddingsService(environment, lazy_load)

        if settings.milestone == Milestone.ONE:
            raise NotImplementedError("Milestone 1 not supported anymore")
            # answering_service = SPARQLAnswerService(sparql_graph)
        elif settings.milestone == Milestone.TWO:
            raise NotImplementedError("Milestone 2 not supported anymore")
            # answering_service = EmbeddingAndKnowledgeAnswerService(sparql_graph, embeddings)
        elif settings.milestone == Milestone.THREE:
            spacy_extractor = SpacyExtractor()
            print("Spacy extractor initialized")
            self.knowledge_answering_service = EmbeddingAndKnowledgeAnswerService(sparql_graph, embeddings, spacy_extractor)
            self.image_person_finder = PersonImageFinder(sparql_graph, spacy_extractor)
            self.recommendation_service = RecommendationService(sparql_graph, environment, lazy_load, spacy_extractor)
        else:  # Final Project
            raise NotImplementedError("Final Project not implemented yet")


        self.question_classifier = QuestionClassifier()

    def get_answer_for_message(self, message: str) -> str:
        """
        Determines the appropriate response for a given message.
        """

        question_type: QuestionCategory = self.question_classifier.classify(message)
        print(f"Question type: {question_type}")

        if question_type == QuestionCategory.SMALLTALK:
            print(f"Use LLM: {settings.use_llm}")
            if settings.use_llm:
                try:
                    return LlmService().small_talk(message)
                except Exception as e:
                    print(f"Error in LLM: {e}")

            if self._is_welcome_message(message):
                return "Hello! Nice to have you here. I can answer multiple questions regarding movies. Let's start!"
            if self._is_end_message(message):
                return "Goodbye! I hope I was able to help you. Feel free to come back anytime."

        elif question_type == QuestionCategory.KNOWLEDGE:
            return self.knowledge_answering_service.get_response(message)
        elif question_type == QuestionCategory.MULTIMEDIA:
            return self.image_person_finder.get_response(message)
        elif question_type == QuestionCategory.RECOMMENDATION:
            return self.recommendation_service.get_response(message)

        return "I'm not sure how to answer that. Can you please rephrase?"

    def _is_welcome_message(self, message: str) -> bool:
        # Expanded list of possible greetings
        greetings = [
            "hi", "hello", "hey", "greetings", "heyo", "hallo", "hi there", "hello there", "hey there",
            "morning", "good morning", "hiya", "what's up", "sup", "yo", "howdy", "good day",
            "good afternoon", "good evening", "evening", "g'day", "salutations"
        ]

        # Clean the message for consistent checking
        message_cleaned = message.lower().strip()

        # Check if any greeting matches and is short enough relative to the full message
        for greeting in greetings:
            greeting_cleaned = greeting.lower()

            if message_cleaned.startswith(greeting_cleaned) and len(greeting_cleaned) * 2 >= len(message_cleaned):
                return True

        return False

    def _is_end_message(self, messages: str) -> bool:
        matches = ["bye", "goodbye", "farewell", "adios", "ciao", "later", "see you", "talk to you later", "ttyl", "goodnight", "night", "sleep", "rest" \
                    "alright thanks", "alright thank you", "thanks", "thank you", "ok thanks", "ok thank you", "okay thanks", "okay thank you", "ok bye", "okay bye", "ok goodbye", "okay goodbye"]
        cleaned_messages = messages.lower().strip()
        for match in matches:
            ending_cleaned = match.lower()
            if cleaned_messages.startswith(ending_cleaned) and len(ending_cleaned) * 2 >= len(cleaned_messages):
                return True

        return False
