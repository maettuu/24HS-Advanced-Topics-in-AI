# how to run this project

# login to website
https://speakeasy.ifi.uzh.ch/

request chat with `fierce-blade`

# Local steps:
- change your shell to your environment (conda, venv, etc)
- `poetry install` to install dependencies and create environment
- `uvicorn app.main:app --reload` to run the project

# To download dataset
- run `python ./utils/download_dataset.py` to download the dataset

# For "production" - preloads everything
- `uvicorn app.main:app`


# Current extractor approach
- We have an NLP query
    - We remove the question mark
    1) Movie Extractor 
        - 1. Extract with NLTK with levhenstein distance for most similar words (with hypens variations if they exist)
        - 1a If no match was found, we extract with fuzzy matcher (maximally one movie will be returned on this point right now)
        - 2. it is theoretically possible to run NER on movies and then fuzzy match them against the extracted movie names but too much work
            - it would work good when we want to extract all movies from a text but nltk with better algo could solve thiss as well
    2) Relationship extractor
        - 1. Manual extraction (like publication date which is weird)
        - 2. Extract with NLTK with levhenstein distance for most similar words (works perfectly for directors and similar)
            - 2a. Extract with fuzzy matcher (maximally one movie will be returned on this point right now - but not that good for relations)
        - 3. Run embedding search
            - Take all relations and embedd them into space
            - take the query without movie remove all stopwords and embedd it, hopefully we get some relationships


# 2nd evaulation - Example queries
- `Who directed the movie "The Matrix"?`
- `What is the genre of the movie "The Matrix"?`
- `What is the publication date of the movie "The Matrix"?`
- `What is the duration of the movie "The Matrix"?`

# 3rd movies evaulation
- images in testing dataset
- `Show me an Picture of Atli Oskar Fjalarsson`

# Movies extraction
- Find all persons (all people with relation is a person) Q5
- Find all movies and their imdb titles?
- Find all personst and their imdb identificators - then query the movies with the imdb identificator

# Atai dataset link
https://files.ifi.uzh.ch/ddis/teaching/ATAI2024/dataset/


# Changelog
28.10.2024
- Processed movienet json to an better structure (key: casts)
    - I ignored every images, that have 2 persons
- Extracted all Humans from KG, and retrained NLTK NER on it with new label person
- Created pipeline which can extract person from a sentence, find the proper imdb_id and then find an random image

29.10.2024
- Question Classifier created
    - Trained on GPT generated examples, SentenceBert with trained simple linear regression to determine that is it
    - Why? it is more flexible, and they are still setnences, might require much more data and they are somehow repetitive 

04.11.2024
- Question classifier implemented in main.py
- Optimalized SPACY loading (only one instance exists)

10.11.2024
- Person image finder implemented
- The person is determines with NER, afterwards the person is searched in the KG and the imdb ID is retrieved
- given an IMDB ID, given custom lookup array (imdb ID to all en)

13.11.2024
- Question classifier - new structure implemented (sentence Transformer + custom NN) for classification
    - This achieves much better accuracy mainly when movies are part of the sentence
- Adapted repository structure
    - New Agent Answering Service - which is responsible for answering the questions (easily to reuse in ipynbs)
    - Loading moved from main loop into agent service
- Improved NER for movies, persons and relation
    - Movies are extracted on lowercase inputs right now
    - firstly an NLTK match is used, afterwards  a fuzzy match is used
    - the final extraction is an combination of both of them based on a longest match on a place -> we can return multiple instances




# What needs to be done
- recommendations S3
- Crowdsourcing S4
- Improved extraction of relations S3/S2
- Improved LLM prompting S3/S4
- Get all entities under one relation - when there are multiple entities under one relation S3

# What could be done
- Answering of extended questions 
    - given that I like movies with XY suggest me something
    - Match harry Potter when it is a partial movie
    - Answer the highest/lowest rated movies
    - Get all movies where XY played
    - Get all movies where XY directed etc


# Evaulation 3 - questions anwers
- "Given that I like Kung Fu Panda, can you recommend some movies?"
   - Have you considered watching Spy Game? I recommend it!
- "Recommend movies like Nightmare on Elm Street, Friday the 13th, and Halloween."
   - Have you considered watching C.H.U.D.? I recommend it!
- "Given that I like The Lion King, Pocahontas, and The Beauty and the Beast, can you recommend some movies?"
   - You might really like Sleeping Beauty, give it a watch!
- "Recommend some movies like The Avengers."
   - How about watching C.H.U.D.? It's worth your time.
- "Recommend movies like Inception."
   - There is no movie worthy of Inception to be recommended.
- "Recommend movies like Interstellar?"
   - Have you considered watching C.H.U.D.? I recommend it!
- "Recommend movies like The Godfathera."
   - You might really like Buffalo '66, give it a watch!
- "Recommend me a movie similar to Deadpool?"
   - Have you considered watching Day of the Comet? I recommend it!
- "Recommend me movie like Harry Potter."
   - I could not find any entity in your message, please try again and reformulate.
- "Recommend movies similar to Hamlet and Othello."
   - How about watching King Lear? It's worth your time.
- "Recommend movies like The Godfather."
   - I think you'd enjoy watching Buffalo '66.
- "I really like The Lion King and Pocahontas, can you recommend some similar movies?"
   - I think you'd enjoy watching Oliver & Company.
- "Recommend me a movie like Harry Potter."
   - I think you'd enjoy watching Forever Enthralled.
- "Recommend movies like Forest Gump and The Lord of the Rings: The Fellowship of the Ring."
   - I think you'd enjoy watching North.
- "Recommend some movies given that I like Ryan Gosling."
   - Have you considered watching Bukowski: Born into This? I recommend it!
- "Given that I like A.I. Artificial Intelligence, can you recommend some movies?"
   - You can't go wrong with Buffalo Girls, I highly recommend it.
- "If I like Matthew McConaughey, recommend some other actors I might like."
   - You can't go wrong with Theeran Athikaram Ondru, I highly recommend it.
- "I like wormhole, what movie would I like."
   - I could not find any entity in your message, please try again and reformulate.



